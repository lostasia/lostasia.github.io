package prog02;

import java.io.*;
import java.util.Scanner;

	/**
	 *
	 * @author vjm
	 */
public class SortedPD extends ArrayBasedPD {
	
	public void loadData (String sourceName) {
		// Remember the source name.
		this.sourceName = sourceName;
		try {
			// Create a BufferedReader for the file.
			Scanner in = new Scanner(new File(sourceName));
			String name;
			String number;

			// Read each name and number and add the entry to the array.
			while (in.hasNextLine()) {
				name = in.nextLine();
				number = in.nextLine();
				// Add an entry for this name and number.
				addLoad(name, number);
			}

			// Close the file.
			in.close();
		} catch (FileNotFoundException ex) {
			// Do nothing: no data to load.
			System.out.println(sourceName + ": file not found.");
			System.out.println(ex);
			return;
		}
	}


	/** Add an entry or change an existing entry.
  	  @param name The name of the person being added or changed
 	  @param number The new number to be assigned
  	  @return The old number or, if a new entry, null
	*/
	public String addOrChangeEntry (String name, String number) {
		String oldNumber = null;
		FindOutput fo = find(name);
		if (fo.found) {
			oldNumber = theDirectory[fo.index].getNumber();
			theDirectory[fo.index].setNumber(number);
		} else {
			add(name, number, fo);
		}
		modified = true;
		return oldNumber;
	}

	/** Find an entry in the directory.
  	  @param name The name to be found
  	  @return A FindOutput object containing the result of the search.
	*/
	protected FindOutput find (String name) {
	
		int i = 0;
		int f = size-1;
		int m = 0;
		String test = null;
		while(f>=i){
			m = (i+f)/2;
			test = theDirectory[m].getName();
			if(name.compareTo(test)<0){
				f = m-1;
			}else if(name.compareTo(test)>0){
				i = m+1;
			} else if(name.compareTo(test) == 0) {
				return new FindOutput(true,m);
			}
		}
		return new FindOutput(false, i);
	}
	
	/** Load the file sorted in order.
      @param name The name of the new person
	  @param number The number of the new person
	*/
	protected void addLoad(String name, String number) {
		if (size >= theDirectory.length) {
			reallocate();
		}
		DirectoryEntry entry = new DirectoryEntry(name,number);
		if (size == 0) {
			theDirectory[0] = entry;
		} else {
			theDirectory[size] = entry;
			int i = size;
			boolean place = false;
			DirectoryEntry replace = null;
			String real = null;
			String test = null;
			do {
				real = theDirectory[i].getName();
				test = theDirectory[i-1].getName();
				if (real.compareTo(test)>0)
					place = true;
				else if (real.compareTo(test)<0) {
					replace = theDirectory[i];
					theDirectory[i] = theDirectory[i-1];
					theDirectory[i-1] = replace;
					i--;
				}
			} while(!place && i>0);
		}
		size++;
	}

	/** Add an entry to the directory.
      @param name The name of the new person
  	  @param number The number of the new person
	*/
	protected void add(String name, String number, FindOutput fo) {
		if (size >= theDirectory.length) {
			reallocate();
		}
		for(int i = size;i > fo.index;i--)
			theDirectory[i]=theDirectory[i-1];
		theDirectory[fo.index] = new DirectoryEntry(name, number);
		size++;
	}

	/** Remove an entry from the directory.
  	  @param name The name of the person to be removed
  	  @return The current number. If not in directory, null is
          	returned
	*/
	public String removeEntry (String name) {
		FindOutput fo = find(name);
		if (!fo.found)
			return null;
		DirectoryEntry entry = theDirectory[fo.index];
		size--;
		for(int i = fo.index;i < size; i++)
			theDirectory[i] = theDirectory[i+1];
		modified = true;
		return entry.getNumber();
	}
}

