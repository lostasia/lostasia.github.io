package prog12;

import java.util.List;

public interface Browser {
	
	/** 
	 * Loads a page via a link.
	 * 
	 * @param url the URL link of the page
	 * @return    true if the page loads, otherwise false.
	 */	
	
    boolean loadPage (String url);
    
    /** 
     * Gets the text contents of the page.
     * 
     * @return A list of words from the page.
     */
    
    List<String> getWords ();
    
    /** 
     * Gets the links of the page.
     * 
     * @return A list of links from the page.
     */
    
    List<String> getURLs ();
}

