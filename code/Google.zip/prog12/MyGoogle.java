package prog12;

import java.util.*;


public class MyGoogle implements Google {

	// Correct Gather Method:
	private boolean print = true;

	/** List of all URLs seen so far, with no duplicates. */
	private List<String> pagesSeen = new ArrayList<String>();

	/** Map from String url to its index in pagesSeen. */
	private Map<String, Integer> pageToIndex = new TreeMap<String, Integer>();

	/**
	 * Number of references (links from other pages) to each page, parallel to
	 * pagesSeen.
	 */
	private List<Integer> refCounts = new ArrayList<Integer>();

	/** Index a new URL */
	private void indexURL(String url) {
		if (print) {
			System.out.println("\nIndexing URL " + url);
			System.out.println("BEFORE");
			System.out.println("pagesSeen " + pagesSeen);
			System.out.println("pageToIndex " + pageToIndex);
			System.out.println("refCounts " + refCounts);
		}
		pagesSeen.add(url);
		pageToIndex.put(url, pagesSeen.size() - 1);
		refCounts.add(0);
		if (print) {
			System.out.println("AFTER");
			System.out.println("pagesSeen " + pagesSeen);
			System.out.println("pageToIndex " + pageToIndex);
			System.out.println("refCounts " + refCounts);
		}
	}

	/** List of all words seen so far, with no duplicates */
	List<String> wordsSeen = new ArrayList<String>();

	/** Map from String word to its index in wordsSeen */
	private Map<String, Integer> wordToIndex = new HashMap<String, Integer>();

	/**
	 * List of lists, parallel to wordsSeen. Each element is the list of URL
	 * indices of pages which contain the corresponding word.
	 */
	private List<List<Integer>> pageIndexLists = new ArrayList<List<Integer>>();

	/** Index a new word. */
	private void indexWord(String word) {
		if (print) {
			System.out.println("\nIndexing word " + word);
			System.out.println("BEFORE");
			System.out.println("wordsSeen " + wordsSeen);
			System.out.println("wordToIndex " + wordToIndex);
			System.out.println("pageIndexLists " + pageIndexLists);
		}
		wordsSeen.add(word);
		wordToIndex.put(word, wordsSeen.size() - 1);
		pageIndexLists.add(new ArrayList<Integer>());
		if (print) {
			System.out.println("AFTER");
			System.out.println("wordsSeen " + wordsSeen);
			System.out.println("wordToIndex " + wordToIndex);
			System.out.println("pageIndexLists " + pageIndexLists);
		}
	}

	/**
	 * Visit every page reachable from the pages with urls in startingURLs.
	 * Index all new URLs and words. Update refCounts and pageIndexLists.
	 * 
	 * @param browser
	 *            a Browser to view the internet
	 * @param startingURLs
	 *            web pages to start from
	 */
	public void gather(Browser browser, List<String> startingURLs) {
		Queue<String> urlQueue = new ArrayDeque<String>();

		// Put unknown pages into the queue, but don't look at them yet.
		for (String url : startingURLs)
			if (!pageToIndex.containsKey(url)) {
				indexURL(url);
				urlQueue.offer(url);
			}

		// Set of page indices of these urls, WITHOUT duplications.
		Set<Integer> pageIndicesOnPage = new HashSet<Integer>();

		// Look at each page in the queue.
		int count = 0;
		while (!urlQueue.isEmpty() && count++ < 100) {
			if (print)
				System.out.println("\nqueue " + urlQueue);
			String url = urlQueue.poll();

			// Clear set of indices of URLs on this page.
			pageIndicesOnPage.clear();

			// The index of the current page.
			int pageIndex = pageToIndex.get(url);
			if (print)
				System.out.println("dequeued " + url + "=" + pageIndex);

			if (browser.loadPage(url)) {
				// List of urls on this page, WITH duplications.
				List<String> urlsOnPage = browser.getURLs();
				if (print)
					System.out.println("\nURLs on page " + urlsOnPage);

				for (String urlOnPage : urlsOnPage) {
					// Index links to unknown pages and put them into the queue.
					if (!pageToIndex.containsKey(urlOnPage)) {
						indexURL(urlOnPage);
						urlQueue.offer(urlOnPage);
						if (print)
							System.out.println("\nenqueuing " + urlOnPage);
					}

					// Get the index of a url linked from the current page.
					int urlIndexOnPage = pageToIndex.get(urlOnPage);

					// If this is the first appearance, increment its refCounts.
					if (!pageIndicesOnPage.contains(urlIndexOnPage)) {
						pageIndicesOnPage.add(urlIndexOnPage);
						if (print) {
							System.out.println("\nincrementing ref count for "
									+ urlOnPage + "=" + urlIndexOnPage);
							System.out.println("BEFORE");
							System.out.println("refCounts " + refCounts);
						}
						refCounts.set(urlIndexOnPage,
								refCounts.get(urlIndexOnPage) + 1);
						if (print) {
							System.out.println("AFTER");
							System.out.println("refCounts " + refCounts);
						}
					} else if (print)
						System.out.println("\n" + urlOnPage
								+ " appeared earlier on page");
				}

				// The words on this page.
				List<String> words = browser.getWords();
				if (print)
					System.out.println("\nwords on page " + words);
				for (String word : words) {
					// Record new words.
					if (!wordToIndex.containsKey(word))
						indexWord(word);

					// Add the page index of this page to the end of the
					// list of page indices for this word, but do it only
					// once even if this word appears multiple times
					// on this page.
					int wordIndex = wordToIndex.get(word);
					List<Integer> list = pageIndexLists.get(wordIndex);
					if (list.isEmpty()
							|| list.get(list.size() - 1) != pageIndex) {
						if (print) {
							System.out.println("\nadding current page " + url
									+ "=" + pageIndex + " to list of " + word
									+ "=" + wordIndex);
							System.out.println("BEFORE");
							System.out.println("pageIndexLists "
									+ pageIndexLists);
						}
						list.add(pageIndex);
						if (print) {
							System.out.println("AFTER");
							System.out.println("pageIndexLists "
									+ pageIndexLists);
						}

					} else if (print)
						System.out.println("\n" + word + "=" + wordIndex
								+ " has already appeared on this page");
				}
			}
		}

		if (true) {
			System.out.println("pagesSeen:");
			System.out.println(pagesSeen);
			System.out.println("pageToIndex:");
			System.out.println(pageToIndex);
			System.out.println("refCounts:");
			System.out.println(refCounts);
			System.out.println("wordsSeen:");
			System.out.println(wordsSeen);
			System.out.println("wordToIndex:");
			System.out.println(wordToIndex);
			System.out.println("pageIndexLists:");
			System.out.println(pageIndexLists);
		}
	}

	// My Gather Method :

	/*	*//**
	 * A list of links of pages we have found.
	 */
	/*
	 * 
	 * private List<String> pagesSeen = new ArrayList<String>();
	 *//**
	 * A TreeMap which returns the index of a page.
	 */
	/*
	 * 
	 * private Map<String, Integer> pageToIndex = new TreeMap<String,
	 * Integer>();
	 *//**
	 * A list which counts the references of a page, corresponding to its
	 * significance.
	 */
	/*
	 * 
	 * private List<Integer> refCounts = new ArrayList<Integer>();
	 *//**
	 * Indexes a new page.
	 * 
	 * @param url
	 *            link of the new page.
	 */
	/*
	 * private void indexPage(String url) {
	 * 
	 * pagesSeen.add(url); pageToIndex.put(url, pagesSeen.size()-1);
	 * refCounts.add(0); }
	 *//**
	 * A list of links of pages we have found.
	 */
	/*
	 * 
	 * private List<String> wordsSeen = new ArrayList<String>();
	 *//**
	 * A HashMap which returns the index of a word.
	 */
	/*
	 * 
	 * private Map<String, Integer> wordToIndex = new HashMap<String,
	 * Integer>();
	 *//**
	 * A list of the page indices from which find a given word.
	 */
	/*
	 * 
	 * private List<List<Integer>> pageIndexLists = new
	 * ArrayList<List<Integer>>();
	 *//**
	 * Indexes a new page.
	 * 
	 * @param url
	 *            link of the new page.
	 */
	/*
	 * private void indexWord(String word) {
	 * 
	 * wordsSeen.add(word); wordToIndex.put(word, wordsSeen.size()-1);
	 * pageIndexLists.add(new ArrayList<Integer>()); }
	 */

	/*
	 * @Override public void gather(Browser browser, List<String> startingURLs)
	 * { // TODO Auto-generated method stub
	 * 
	 * Queue<String> pages = new ArrayDeque<String>(); List<String> urls = new
	 * ArrayList<String>(); List<String> words = new ArrayList<String>();
	 * List<Integer> wordL = new ArrayList<Integer>(); Set<Integer> refs = new
	 * HashSet<Integer>();
	 * 
	 * if(startingURLs != null) { for(int i = 0; i < startingURLs.size(); i++) {
	 * pages.offer(startingURLs.get(i)); indexPage(startingURLs.get(i)); } }
	 * 
	 * while(!pages.isEmpty()) { String name = pages.poll();
	 * browser.loadPage(name); urls = browser.getURLs(); words =
	 * browser.getWords(); refs.clear();
	 * 
	 * for(int i = 0; i< urls.size(); i++) { String url = urls.get(i);
	 * if(pageToIndex.get(url) == null) { pages.offer(url); indexPage(url); }
	 * int index = pageToIndex.get(url); if(!refs.contains(index)) {
	 * refCounts.set(index, refCounts.get(index)+1); refs.add(index); } }
	 * 
	 * for(int i = 0; i< words.size(); i++) { String word = words.get(i);
	 * if(wordToIndex.get(word) == null) indexWord(word); int index =
	 * wordToIndex.get(word); wordL = pageIndexLists.get(index); int indexP =
	 * pageToIndex.get(name); if(wordL.size() == 0 ||
	 * !wordL.get(wordL.size()-1).equals(indexP)) wordL.add(indexP); } }
	 * 
	 * 
	 * }
	 */

	@Override
	public String[] search(List<String> keyWords, int numResults) {
		// TODO Auto-generated method stub

		// Iterator into list of page ids for each key word.
		Iterator<Integer>[] pageIndexIterators = 
			(Iterator<Integer>[]) new Iterator[keyWords
				.size()];

		// Current page index in each list, just ``behind'' the iterator.
		int[] currentPageIndices = new int[keyWords.size()];

		// LEAST popular page is at top of heap so if heap has numResults
		// elements and the next match is better than the least popular page
		// in the queue, the least popular page can be thrown away.

		PriorityQueue<Integer> bestPageIndices;
		
		for(int i = 0; i < keyWords.size(); i++) {
			String word = keyWords.get(i);
			if(wordToIndex.get(word) == null) 
				return new String[0];
			int indexW = wordToIndex.get(word);
			List<Integer> refL = pageIndexLists.get(indexW);
			pageIndexIterators[i] = refL.iterator();
			currentPageIndices[i] = pageIndexIterators[i].next();
		}
		

		PageComparator comparator = new PageComparator();
		Stack<String> helper = new Stack<String>();
		bestPageIndices = new PriorityQueue<Integer>(numResults, comparator);
		
		do {
			if (allEqual(currentPageIndices)) 
				bestPageIndices.offer(currentPageIndices[0]);
		} while (moveForward(currentPageIndices, pageIndexIterators));

		
		while (!bestPageIndices.isEmpty()) 
			helper.push(pagesSeen.get(bestPageIndices.poll())) ;
		int index = 0;
		String[] results = new String[helper.size()];
		while(!helper.empty()){
			results[index] = helper.pop();
			index++;
		}
		return results;
	}

	private class PageComparator implements Comparator<Integer> {

		@Override
		public int compare(Integer page1, Integer page2) {
			// TODO Auto-generated method stub
			int ref1 = refCounts.get(page1);
			int ref2 = refCounts.get(page2);
			return ref1 - ref2;
		}

	}
	
	/** If all the currentPageIndices are the same (because are just
    starting or just found a match), move them all forward: call
    next() for each page index iterator and put the result into
    current page indices.
 
    If they are not all the same, don't move the largest one(s)
    forward.  (There may be more than one equal to the largest index
    in current page indices.)

    Return false if hasNext() is false for any iterator.

    @param currentPageIndices array of current page indices
    @param pageIndexIterators array of iterators with next page indices
    @return true if all minimum page indices updates, false otherwise
*/
private boolean moveForward
  (int[] currentPageIndices, Iterator<Integer>[] pageIndexIterators) {
	
	if(allEqual(currentPageIndices)) {
		for(int i = 0; i < currentPageIndices.length; i++) {
			if(pageIndexIterators[i].hasNext())
				currentPageIndices[i] = pageIndexIterators[i].next();
			else
				return false;
		}
		return true;
	} else {
		int i = 0;
		int test;
		int largest = currentPageIndices[0];
		do {
			test = currentPageIndices[i];
			
			if (test - largest > 0) 
				largest = test;
			i++;
		} while (i < currentPageIndices.length);
		
		for(int j = 0; j< currentPageIndices.length; j++) {
			if(currentPageIndices[j] < largest) {
				if(pageIndexIterators[j].hasNext())
					currentPageIndices[j] = pageIndexIterators[j].next();			
				else 
					return false;
			}
		}		
		return true;
	}


}

/** Check if all elements in an array are equal.
@param array an array of numbers
@return true if all are equal, false otherwise
*/
private boolean allEqual (int[] array) {
	for(int i = 0; i < array.length - 1; i++) {
		if(array[i] != array[i+1])
			return false;
	}
	return true;

}

}
