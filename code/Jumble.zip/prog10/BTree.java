package prog10;

import java.util.*;

public class BTree<K extends Comparable<K>, V> extends AbstractMap<K, V>
		implements Map<K, V> {

	/**
	 * At the bottom of the tree, this is an ordinary (prog02) directory entry
	 * in the directory list. It contains the V value in listOrValue. Inside the
	 * tree, this is a list entry. Its listOrValue points to list the next level
	 * down.
	 */
	private class Entry<K extends Comparable<K>, V> implements Map.Entry<K, V> {
		private K key;
		private Object listOrValue;

		private Entry(K key, V value) {
			this.key = key;
			listOrValue = value;
		}

		private Entry(ArrayList<Entry<K, V>> list) {
			key = list.get(0).key;
			listOrValue = list;
		}

		private boolean bottom() {
			return !(listOrValue != null && listOrValue instanceof ArrayList
					&& getList().size() > 0 && getList().get(0) instanceof Entry);
		}

		public K getKey() {
			return key;
		}

		public V getValue() {
			return (V) listOrValue;
		}

		public V setValue(V value) {
			V old = getValue();
			listOrValue = value;
			return old;
		}

		public ArrayList<Entry<K, V>> getList() {
			return (ArrayList<Entry<K, V>>) listOrValue;
		}

		public String toString() {
			return "" + getKey() + " " + getValue();
		}
	}

	// (4) means give it a capacity (length) of 4. size is set to 0.
	private ArrayList<Entry<K, V>> list = new ArrayList<Entry<K, V>>(4);

	/**
	 * Find the index of the entry that contains key or the index at which it
	 * should be inserted. This is like the find method in prog02 except you
	 * should not bother with binary search since n is so small. For example if
	 * list.get(0).key equals "Alex" list.get(1).key equals "Lisa"
	 * list.get(2).key equals "Reid" findInList("Lisa", list) should return 1
	 * because that's Lisa's index, but findInList("Hal", list) should also
	 * return 1 because that's where Hal should go, and findInList("Zoe", list)
	 * should return 3, right? What about findInList("Aaron", list)?
	 */
	private int findInList(K key, ArrayList<Entry<K, V>> list) {
		// EXERCISE
		for (int i = list.size() - 1; i >= 0; i--) {
			if (list.get(i).key.compareTo(key) < 0)
				return i + 1;
			else if (list.get(i).key.equals(key))
				return i;
		}
		return 0;
	}

	/**
	 * The previous find method was like the one in prog02. This
	 * findInListOfLists method is for finding which list, in a list of lists,
	 * contains the key we are looking for. It returns -1 if the key is
	 * definitely not there. If the keys are as stated in the previous example,
	 * list.get(0).getList() contains "Alex" up to (but not including) "Lisa"
	 * list.get(1).getList() contains "Lisa" up to (but not including) "Reid"
	 * list.get(2).getList() contains "Reid" and beyond.
	 * findInListOfLists("Lisa") should still be 1, but findInListOfLists("Hal")
	 * should be 0 now, and findInListOfLists("Zoe") should be 2, and
	 * findInListOfLists("Aaron") should be -1.
	 */
	private int findInListOfLists(K key, ArrayList<Entry<K, V>> list) {
		// EXERCISE
		for (int i = list.size() - 1; i >= 0; i--) {
			if (list.get(i).key.compareTo(key) <= 0)
				return i;
		}
		return -1; // This is incorrect sometimes.
	}

	/**
	 * Recursively find the leaf entry for the key in the tree. Return null if
	 * not there.
	 */
	private Entry<K, V> find(K key, ArrayList<Entry<K, V>> list) {
		// If the list is empty, it is not there.
		if (list.size() == 0)
			return null;
		int index;
		Entry<K, V> target;

		// If the list entries are leaves (contain data not lists):
		if (list.get(0).bottom()) {
			// EXERCISE
			// Use findInList to get the index of the key, if it is there.

			// Check if the entry at that index matches the key.
			// (Be careful looking for Zoe.)
			index = findInList(key, list);
			if (index != list.size()) {
				target = list.get(index);
				if (target.key.equals(key))
					return target;
			}
			return null; // if it is not there
		}
		// List entries are lists.
		else {
			// EXERCISE
			// Use findInListOfLists to get the index of the list that has
			// the key in it, if it is there.

			// If it is not Aaron, recursively find the key in the list at i.

			index = findInListOfLists(key, list);
			if (index != -1) {
				return find(key, list.get(index).getList());
			}
			return null;
		}
	}

	public boolean containsKey(K key) {
		return find(key, list) != null;
	}

	public V get(Object obj) {
		K key = (K) obj;
		Entry<K, V> entry = find(key, list);
		if(entry == null)
			return null;
		return entry.getValue();
	}

	/**
	 * Split off a right hand list for a list containing four elements. Before
	 * this call, original list contains [0], [1], [2], [3]. After the call,
	 * original list contains [0] and [1], and returned list contains what used
	 * to be [2] and [3]. As always, new list capacity should be 4.
	 */
	private ArrayList<Entry<K, V>> split(ArrayList<Entry<K, V>> list) {
		ArrayList<Entry<K, V>> right = new ArrayList<Entry<K, V>>(4);
		right.add(list.get(2));
		right.add(list.get(3));
		list.remove(3);
		list.remove(2);
		return right;
	}

	public V put(K key, V value) {
		Entry<K, V> entry = find(key, list);
		if (entry != null) {
			V old = entry.getValue();
			entry.setValue(value);
			return old;
		}

		insert(key, value, list);

		// Look at this!!!
		if (list.size() == 4) {
			ArrayList<Entry<K, V>> left = list;
			ArrayList<Entry<K, V>> right = split(list);
			list = new ArrayList<Entry<K, V>>(4);
			list.add(new Entry<K, V>(left));
			list.add(new Entry<K, V>(right));
		}

		return null;
	}

	/**
	 * Recursively insert an entry with key and value into list. Precondition:
	 * entry must not be there.
	 */
	private void insert(K key, V value, ArrayList<Entry<K, V>> list) {
		// If we are at the bottom level:
		if (list.size() == 0 || list.get(0).bottom()) {

			// EXERCISE

			// Create a new Entry.

			// Remember: this is an ordinary list of entries (leaf not
			// internal).
			// How do you get the index where to insert it?

			// Insert it using a method in the List API.
			// Just one line. No loop necessary.
			Entry<K, V> entry = new Entry<K, V>(key, value);
			int index = findInList(key, list);
			list.add(index, entry);

		}
		// Not at the bottom level -- list of lists.
		else {
			// EXERCISE

			// Get the index at which it should be inserted.
			int i = -1; // Not -1. How do you find it?
			i = findInListOfLists(key, list);
			// Where should Aaron go? (Modify i for that case.)
			if (i == -1)
				i = 0;

			// Get the entry and sublist at that index.
			Entry<K, V> entry = list.get(i);
			ArrayList<Entry<K, V>> sublist = entry.getList();

			// Insert the key and value into that sublist (recursively).
			insert(key, value, sublist);
			// In case we inserted Aaron, the entry key changes.
			entry.key = sublist.get(0).key;

			// Sublist is too big, needs to be split.
			if (sublist.size() == 4) {
				ArrayList<Entry<K, V>> rightlist = split(sublist);

				// EXERCISE
				// Create a new Entry with rightlist.
				// Insert it into list. What index? (Hint: to the right of index
				// i.)
				Entry<K, V> right = new Entry<K, V>(rightlist);
				list.add(i + 1, right);
			}
		}
	}

	public V remove(K key) {
		Entry<K, V> entry = find(key, list);

		if (entry == null)
			return null;

		remove(key, list);

		// EXERCISE
		// If the list has only one element and that element is not a
		// leaf, then throw away the list and that entry and set list
		// equal to that entry's list.
		Entry<K, V> head = list.get(0);
		if (list.size() == 1 && !head.bottom()) {
			list = head.getList();
		}
		return entry.getValue();
	}

	/**
	 * Recursively remove the entry with key from the list. Precondition: entry
	 * must be there.
	 */
	private void remove(K key, ArrayList<Entry<K, V>> list) {
		// EXERCISE
		Entry<K, V> target;

		// If we are at the bottom level:

		// Find the index of the key and remove the entry at that index.
		// The List API has a remove method you should use.
		if (list.get(0).bottom()) {
			int index = findInList(key, list);
			if (index != list.size()) {
				target = list.get(index);
				if (target.key.equals(key))
					list.remove(index);
			}
		}

		// Not at bottom level:
		// Find the index of the sublist which contains the key.

		// Get the entry at that index.

		// Get its list, call it the sublist.

		// Recursively remove the key from that sublist.

		// Make sure to update the key field of the entry because the
		// sublist may have a new key at index 0 now.
		else {
			int index = findInListOfLists(key, list);
			Entry<K, V> entry = list.get(index);
			ArrayList<Entry<K, V>> sublist = entry.getList();
			remove(key, sublist);
			entry.key = sublist.get(0).key;

			// If the size of the sublist equals 1:

			// We need to merge the sublist with its left or right
			// neighbor in list. To keep things simple, merge it with the
			// one on the right, with index+1, but if the index is the
			// last index, that's not going to work. So in that case,
			// first decrement the index and make the entry and sublist be
			// the ones which belong to that one.

			// Add all the elements of the sublist to the right to the current
			// sublist. You can just use the addAll method of ArrayList.

			// Remove the entry to the right from list.
			if (sublist.size() == 1) {
				ArrayList<Entry<K, V>> sublistRight;
				if (index == list.size() - 1) {
					entry = list.get(--index);
					sublist = entry.getList();
				}
				sublistRight = list.get(index + 1).getList();
				sublist.addAll(sublistRight);
				list.remove(index+1);
			}

			// If the size of the sublist is now 4:

			// Split the sublist. Look at insert to see how this is
			// done.
			if (sublist.size() == 4) {
				ArrayList<Entry<K, V>> rightlist = split(sublist);
				Entry<K, V> right = new Entry<K, V>(rightlist);
				list.add(index + 1, right);
			}
		}
	}

	// Required to implement Map<K, V>.
	public Set<Map.Entry<K, V>> entrySet() {
		return null;
	}

	public String toString() {
		return "-------------------------\n" + toString(list, 0);
	}

	private String toString(ArrayList<Entry<K, V>> list, int indent) {
		String ret = "";
		for (int i = 0; i < list.size(); i++) {
			for (int j = 0; j < indent; j++)
				ret = ret + "    ";
			ret = ret + list.get(i).key;
			if (list.get(i).bottom())
				ret = ret + " " + list.get(i).getValue() + "\n";
			else
				ret = ret + "\n" + toString(list.get(i).getList(), indent + 4);
		}
		return ret;
	}

	public static void main(String[] args) {
		BTree<String, Integer> tree = new BTree<String, Integer>();

		tree.put("Brad", 46);
		System.out.println(tree);
		tree.put("Hal", 10);
		System.out.println(tree);
		tree.put("Kyle", 6);
		System.out.println(tree);
		tree.put("Lisa", 43);
		System.out.println(tree);
		tree.put("Lynne", 43);
		System.out.println(tree);
		tree.put("Victor", 46);
		System.out.println(tree);
		tree.put("Zoe", 6);
		System.out.println(tree);
		tree.put("Zoran", 76);
		System.out.println(tree);

		tree.remove("Zoe");
		System.out.println(tree);
		tree.remove("Kyle");
		System.out.println(tree);
		tree.remove("Brad");
		System.out.println(tree);
		tree.remove("Zoran");
		System.out.println(tree);
		tree.remove("Lisa");
		System.out.println(tree);
	}
}
