package prog07;
import java.util.*;

public class DummyList <K extends Comparable<K>, V>
  extends AbstractMap<K, V> {

  private static class Node <K extends Comparable<K>, V>
    implements Map.Entry<K, V> {

    K key;
    Object valueOrDown;
    Node<K, V> next;
    Node () {}

    // Use this constructor for DummyList.
    Node (K key, V value, Node<K, V> next) {
      this.key = key;
      this.valueOrDown = value;
      this.next = next;
    }
    
    // And these methods.
    public K getKey () { return key; }
    public V getValue () { return (V) valueOrDown; }
    public V setValue (V newValue) {
      V oldValue = getValue();
      valueOrDown = newValue;
      return oldValue;
    }

    /** Does next point to a Node with the given key?
     *  @param key The given key.
     *  @return true if next.key is that same as key, false otherwise.
     */
    boolean keyIsNext (K key) {
      // EXERCISE
    	if(next != null && next.key.equals(key))
    		return true;
    	return false;
      

    }

    // NEEDED FOR SkipList
    Node (K key, Node<K, V> down, Node<K, V> next) {
      this.key = key;
      this.valueOrDown = down;
      this.next = next;
    }
    
    Node<K, V> getDown () { return (Node<K,V>) valueOrDown; }
  }
  
  private Node<K, V> bottomDummy = new Node<K,V>();
  private Node<K, V> topDummy = bottomDummy;
  private int height = 1;
  private int size = 0;
  
  boolean heads () { return Math.random() < 0.5; }

  /**
   * Find the node that comes before the given key.
   * If the key is not there, the node comes before where the key
   * should be.
   * @param start The node to start from.
   * @param key The key to be found.
   * @return The last node on that level that comes before that key.
   */
  private Node<K, V> findPrevious (Node<K, V> start, K key) {
    Node<K, V> node = start;

    // EXERCISE
    // Move node forward as much as possible.
    
    while(node.next != null) {
    	if(node.next.key.compareTo(key) >= 0)
    		break;
    	node = node.next;
    }
    return node;
  }    

  /**
   * Find the node with the given key.
   * @param key The key to be found.
   * @return The node or null if it is not there.
   */
  private Node<K, V> find (K key) {
    Node<K, V> node = topDummy;

    node = findPrevious(node, key);
    if (node.keyIsNext(key))
      return node.next;
    else
      return null;
  }    
  
  /**
   * Add a new node with the given key and value to the ordered list.
   * Node with that key is not in the list.
   * @param key The key of the new node.
   * @param value The value of the new node.
   */
  private void add (K key, V value) {
    Node<K, V> node = topDummy;
    
    // EXERCISE
    // Make sure you understand the find method above.
    // Understand means you can write it again without looking!
    node = findPrevious(node,key);
    Node<K, V> newNode = new Node<K,V> (key, value, null);
    if(node.next == null) {
    	node.next = newNode;
    } else { 
    	newNode.next = node.next;
    	node.next = newNode;
    }    	
    size++;
  }

  /** Documented in java.util.Map */
  public V remove (Object keyAsObject) {
    K key = (K) keyAsObject;
    V value = null;
    Node<K, V> node = topDummy;

    // EXERCISE
    // Don't forget to decrement size if you actually remove it.
    node = findPrevious(node,key);
    if(!node.keyIsNext(key))
    	return null;
    value = node.next.getValue();
    node.next = node.next.next;
    size--;
    return value;
  }      

  public boolean containsKey (Object key) {
    return find((K) key) != null;
  }
  
  /** Documented in java.util.Map */
  public V get (Object key) {
    Node<K, V> node = find((K) key);
    if (node != null)
      return node.getValue();
    return null;
  }
  
  public boolean isEmpty () { return size == 0; }
  
  public V put (K key, V value) {
    Node<K, V> keyNode = find(key);

    if (keyNode != null) {
      V oldValue = keyNode.getValue();
      keyNode.setValue(value);
      return oldValue;
    }
    else {
      add(key, value);
      return null;
    }
  }      
  
  private static class Iter<K extends Comparable<K>, V> implements Iterator<Map.Entry<K, V>> {
    Node<K, V> previous;
    
    Iter (Node<K, V> dummy) {
      previous = dummy;
    }
    
    public boolean hasNext () { return previous.next != null; }
    
    public Map.Entry<K, V> next () {
      if (!hasNext())
        throw new NoSuchElementException();
      previous = previous.next;
      return previous;
    }
    
    public void remove () {
      throw new UnsupportedOperationException();
    }
  }
  
  private class Setter extends AbstractSet<Map.Entry<K, V>> {
    public Iterator<Map.Entry<K, V>> iterator () {
      return new Iter(bottomDummy);
    }
    
    public int size () { return size; }
  }
  
  public Set<Map.Entry<K, V>> entrySet () { return new Setter(); }
  
  void print () {
    for (Node<K,V> start = topDummy; start != null; start = start.getDown()) {
      for (Node<K,V> node = start; node != null; node = node.next)
        System.out.print(node + "," + node.key + "," + node.valueOrDown + "," + node.next + " ");
      System.out.println();
    }
  }

  public static void main (String[] args) {
    DummyList<String, Integer> map = new DummyList<String, Integer>();
    
    map.put("Victor", 50);
    map.put("Irina", 45);
    map.put("Lisa", 47);
    
    map.print();

    for (Map.Entry<String, Integer> pair : map.entrySet())
      System.out.println(pair.getKey() + " " + pair.getValue());

    System.out.println("Done printing map.");
    
    System.out.println(map.get("Irina"));
    map.remove("Irina");
    
    for (Map.Entry<String, Integer> pair : map.entrySet())
      System.out.println(pair.getKey() + " " + pair.getValue());
    
    System.out.println(map.get("Irina"));
  }
}

