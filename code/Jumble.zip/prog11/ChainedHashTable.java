package prog11;

import java.util.*;

public class ChainedHashTable<K, V> extends AbstractMap<K, V> {
	private static class Node<K, V> implements Map.Entry<K, V> {
		K key;
		V value;
		Node<K, V> next;

		public K getKey() {
			return key;
		}

		public V getValue() {
			return value;
		}

		public V setValue(V value) {
			return this.value = value;
		}

		Node(K key, V value, Node<K, V> next) {
			this.key = key;
			this.value = value;
			this.next = next;
		}
	}

	private final static int DEFAULT_CAPACITY = 5;
	private Node<K, V>[] table = new Node[DEFAULT_CAPACITY];
	private int size;

	private int hashIndex(Object key) {
		int index = key.hashCode() % table.length;
		if (index < 0)
			index += table.length;
		return index;
	}

	private Node<K, V> find(Object key) {
		int index = hashIndex(key);
		for (Node<K, V> node = table[index]; node != null; node = node.next)
			if (key.equals(node.key))
				return node;
		return null;
	}

	public boolean containsKey(Object key) {
		return find(key) != null;
	}

	public V get(Object key) {
		Node<K, V> node = find(key);
		if (node == null)
			return null;
		return node.value;
	}

	public V put(K key, V value) {
		Node<K, V> node = find(key);
		if (node != null) {
			V old = node.value;
			node.value = value;
			return old;
		}
		if (size == table.length)
			rehash(2 * table.length);
		int index = hashIndex(key);
		table[index] = new Node<K, V>(key, value, table[index]);
		size++;
		return null;
	}

	public V remove(Object key) {
		// Get the index for the key.
		int index = hashIndex(key);

		// Deal with the case that the linked list at that index is empty.
		if (table[index] == null)
			return null;

		// Deal with the case that the key belongs to the first
		// element in that list
		if (table[index].key.equals(key)) {
			V oldValue = table[index].value;
			table[index] = table[index].next;
			size--;
			return oldValue;
		}

		// Deal with the case that the key belongs to some other
		// element in that list.
		for (Node<K, V> node = table[index]; node != null; node = node.next)
			if (node.next.key.equals(key)) {
				V oldValue = node.next.value;
				node.next = node.next.next;
				size--;
				return oldValue;
			}

		// Return null otherwise.
		return null;
	}

	private void rehash(int newCapacity) {
		// IMPLEMENT
		Node<K, V>[] oldTable = table;
		table = new Node[newCapacity];
		Node<K, V> node;
		size = 0;
		for (int i = 0; i < oldTable.length; i++) {
			node = oldTable[i];
			while (node != null) {
				put(node.key, node.value);
				node = node.next;
			}
		}

	}

	private Iterator<Map.Entry<K, V>> nodeIterator() {
		return new NodeIterator();
	}

	private class NodeIterator implements Iterator<Map.Entry<K, V>> {
		// EXERCISE		
		Node<K, V> node;
		int i = 0;
		boolean head = true;
		

		public boolean hasNext() {
			// EXERCISE
			for (int c = i; c < table.length; c++) {
				if (table[c] != null)
					return true;
			}
			return false;
		}

		public Map.Entry<K, V> next() {
			// EXERCISE
			if(!hasNext())
				throw new NoSuchElementException();
			if(head) 
				node = table[i];
			else 
				node = node.next;
			
			while(node == null) {
				node = table[++i];
				head = true;
			}
			if(node.next == null) {
				i++;
				head = true;
				return node;
			} else {
				head = false;
			}

			return node;
		}

		public void remove() {
		}
	}

	public Set<Map.Entry<K, V>> entrySet() {
		return new NodeSet();
	}

	private class NodeSet extends AbstractSet<Map.Entry<K, V>> {
		public int size() {
			return size;
		}

		public Iterator<Map.Entry<K, V>> iterator() {
			return nodeIterator();
		}

		public void remove() {
		}
	}

	public String toString() {
		String ret = "-------------------------------\n";
		for (int i = 0; i < table.length; i++) {
			ret = ret + i + ":";
			for (Node<K, V> node = table[i]; node != null; node = node.next)
				ret = ret + " " + node.key + " " + node.value;
			ret = ret + "\n";
		}
		return ret;
	}

	public static void main(String[] args) {
		ChainedHashTable<String, Integer> table = new ChainedHashTable<String, Integer>();

		table.put("Brad", 46);
		System.out.println(table);
		table.put("Hal", 10);
		System.out.println(table);
		table.put("Kyle", 6);
		System.out.println(table);
		table.put("Lisa", 43);
		System.out.println(table);
		table.put("Lynne", 43);
		System.out.println(table);
		table.put("Victor", 46);
		System.out.println(table);
		table.put("Zoe", 6);
		System.out.println(table);
		table.put("Zoran", 76);
		System.out.println(table);

		for (String key : table.keySet())
			System.out.print(key + " ");
		System.out.println();

		table.remove("Zoe");
		System.out.println(table);
		table.remove("Kyle");
		System.out.println(table);
		table.remove("Brad");
		System.out.println(table);
		table.remove("Zoran");
		System.out.println(table);
		table.remove("Lisa");
		System.out.println(table);
	}
}
